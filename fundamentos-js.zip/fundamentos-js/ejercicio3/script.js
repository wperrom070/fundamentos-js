let persona = {
    nombre: "María",
    edad: 20,
    esEstudiante: true,
    hobbies: ["leer", "bailar", "cantar"],
    direccion: {
        calle: "Calle Federico García",
        numero: 45,
        ciudad: "Almería"
    }
};

console.log("Objeto persona:", persona);
console.table(persona);