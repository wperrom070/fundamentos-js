
let nombre = "Laura";            
let edad = 19;                  
let esEstudiante = true;        
let favoritos = ["Libros", "Videojuegos", "Música"]; 
let persona = {                 
    nombre: "Laura",
    edad: 19,
    estudiante: true 
};

console.log("Nombre:", nombre, "||||  Tipo:", typeof nombre);
console.info("Edad:", edad, "||||  Tipo:", typeof edad);
console.error("Es estudiante:", esEstudiante, "||||  Tipo:", typeof esEstudiante);
console.debug("Favoritos:", favoritos, "||||  Tipo:", typeof favoritos);
console.log("Objeto persona:", persona, "||||  Tipo:", typeof persona);
