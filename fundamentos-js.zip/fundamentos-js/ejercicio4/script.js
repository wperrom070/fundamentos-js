let num1 = Number(prompt("Ingresa el primer número:"));
let num2 = Number(prompt("Ingresa el segundo número:"));

let suma = num1 + num2;

console.log("La suma de", num1, "+", num2, "es:", suma);